package com.example.weatherapp;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.util.Log;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLConnection;

public class MainActivity extends AppCompatActivity {

    String reader;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Thread t1 = new Thread(){
            public void run(){

                try {

                    URL url = new URL("http://api.openweathermap.org/data/2.5/forecast?id=524901&appid=542dd011885e8b290483d27482397b94");

                    URLConnection urlConnection = url.openConnection();
                    InputStream inputStream = urlConnection.getInputStream();
                    BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(inputStream));
                    String read;
                    while((read = bufferedReader.readLine()) != null){
                        reader += read;
                    }
                } catch(IOException e){
                    e.printStackTrace();
                }

            }

            JSONObject json = new JSONObject();


        };

        t1.start();
        try {
            t1.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        Log.d("TAG", reader);


    }

    }